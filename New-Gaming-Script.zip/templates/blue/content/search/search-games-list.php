<div class="post">
    <a href="{{SEARCH_GAME_URL}}">
        <img src="{{SEARCH_GAME_IMAGE}}" alt="{{SEARCH_GAME_NAME}}">
        <p class="post-name">{{SEARCH_GAME_NAME}}</p>

        {{SEARCH_GAME_FEATURED}}
</div>