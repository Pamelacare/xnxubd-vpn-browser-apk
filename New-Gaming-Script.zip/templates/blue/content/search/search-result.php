<div id="content" style="margin-bottom:50px;">
	{{SEARCH_GAMES_LIST}}
</div>