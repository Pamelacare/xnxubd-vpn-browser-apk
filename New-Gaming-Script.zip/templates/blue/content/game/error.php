<div class="gamemonetize-main span100">
	<div class="_a-c _e55">
		<div>
			<img src="{{CONFIG_THEME_PATH}}/image/icon-color/kite.png">
		</div>
		<h3>@error_game_404@</h3>
	</div>
</div>