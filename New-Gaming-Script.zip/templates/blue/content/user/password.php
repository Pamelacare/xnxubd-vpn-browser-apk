    <div class="gamemonetize-setting _a-r">
        <form class="update-user-password" method="post">
            <div class="form-header">
                <span class="_content-title">
                    @change_password@
                </span> 
            </div>

            <div class="gamemonetize-info-input">
                <input type="password" name="current_password" placeholder="@current_password@">
            </div>
            <div class="gamemonetize-info-input">
                <input type="password" name="new_password" placeholder="@new_password@">
            </div>
            <div class="gamemonetize-info-input">
                <input type="password" name="new_password_v" placeholder="@repeat_new_password@">
            </div>

            <button type="submit" class="btn-p btn-p1">
                <i class="fa fa-check icon-middle"></i>
                @change@
            </button>
        </form>
    </div>