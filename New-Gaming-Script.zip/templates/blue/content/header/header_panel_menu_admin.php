<li>
	<a class="spf-link" href="{{CONFIG_SITE_URL}}/admin">
		<i class="fa fa-cog icon-middle"></i>
		@admin_panel@ 
	</a>
</li>