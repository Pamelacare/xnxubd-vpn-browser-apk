<div class="item-c-media" data-href="{{PROFILE_GAME_PLAYED_URL}}">
	<span class="game-c-media">
		<img src="{{PROFILE_GAME_PLAYED_IMAGE}}">
	</span>
	<h1 class="c-title ellipsis">{{PROFILE_GAME_PLAYED_NAME}}</h1>
	<img class="game-b-media-img" src="{{PROFILE_GAME_PLAYED_IMAGE}}">
</div>