 <script>
 window.location.href = "/";
</script>