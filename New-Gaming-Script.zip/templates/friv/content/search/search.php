<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>
<div class="ad728list">
{{ADS_TOP}}
</div>

<div style="text-align:center;font-size:20px;margin-bottom:10px;margin-top:20px;color:white;">
		@search_to@ 
		<strong style="color:#ff4ffa">{{SEARCH_PARAMETER}}</strong>
</div>

<div class="content" style="text-align:center;">
	{{SEARCH_RESULT}}
</div>

{{FOOTER_CONTENT}}