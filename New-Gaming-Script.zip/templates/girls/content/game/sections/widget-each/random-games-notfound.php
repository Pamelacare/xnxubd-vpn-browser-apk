<li class="item" style="text-align:center;font-size:20px;margin-bottom:10px;margin-top:20px;color:black;">
	<div class="small _a-c">@no_games_found@</div>
</li>